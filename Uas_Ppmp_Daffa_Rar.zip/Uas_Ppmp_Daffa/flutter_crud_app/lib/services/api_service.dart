import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/student.dart';

class ApiService {
  // Untuk Android Emulator gunakan 10.0.2.2
  // Untuk iOS Simulator gunakan localhost
  // Untuk Device fisik, gunakan IP Address komputer (misal: 192.168.1.100)
  static const String baseUrl = 'http://192.168.189.106/flutter_crud_app/api';
  static Future<List<Student>> getStudents() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/read.php'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          List<dynamic> studentsJson = data['data'];
          return studentsJson.map((json) => Student.fromJson(json)).toList();
        } else {
          throw Exception(data['message'] ?? 'Unknown error');
        }
      } else {
        throw Exception('Failed to load students: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  static Future<Student> getStudent(int id) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/read.php?id=$id'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          return Student.fromJson(data['data']);
        } else {
          throw Exception(data['message'] ?? 'Student not found');
        }
      } else {
        throw Exception('Failed to load student: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  static Future<bool> createStudent(Student student) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/create.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(student.toJson()),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['success'] == true;
      } else {
        return false;
      }
    } catch (e) {
      print('Create student error: $e');
      return false;
    }
  }

  static Future<bool> updateStudent(Student student) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/update.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(student.toJson()),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['success'] == true;
      } else {
        return false;
      }
    } catch (e) {
      print('Update student error: $e');
      return false;
    }
  }

  static Future<bool> deleteStudent(int id) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/delete.php?id=$id'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['success'] == true;
      } else {
        return false;
      }
    } catch (e) {
      print('Delete student error: $e');
      return false;
    }
  }
}
