class Student {
  final int? id;
  final String name;
  final String email;
  final String phone;
  final String address;
  final String? createdAt;
  final String? updatedAt;

  Student({
    this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.address,
    this.createdAt,
    this.updatedAt,
  });

  factory Student.fromJson(Map<String, dynamic> json) {
    return Student(
      id: int.tryParse(json['id'].toString()),
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      phone: json['phone'] ?? '',
      address: json['address'] ?? '',
      createdAt: json['created_at'],
      updatedAt: json['updated_at'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'address': address,
    };
  }
}
